<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>my page</title>
</head>
<body>
<div id="container">
	<h1>MY PAGE VIEW2</h1>

    <br>
       <a href="http://[::1]/CI/index.php/Hello">Link to Hello</a>
       <br>
       <a href="http://[::1]/CI/index.php/Welcome">Link to welcome</a>
       <br>
    <img src="http://[::1]/CI/img/me.jpg" alt="" width="200px">
   
</body>
</html>