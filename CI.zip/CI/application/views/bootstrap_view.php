<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>bootstrap</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Prompt&display=swap" rel="stylesheet">

  
</head>
<body> 
<style>
  div{
    background-color: #000000;
    background-image: url('https://i.pinimg.com/564x/bf/22/67/bf226781e4b6dd53b2b6f0a773c7f85b.jpg');
    background-position: center;
    text-shadow: 5px 5px 5px rgba(0, 0, 0, 0.8);
    font-family: 'Prompt', monospace;
      
  }
      
</style>
  
  <!--การสร้างเมนู-->
  <header>
	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
	<div class="container-fluid">
	<a class="navbar-brand  link-dark btn btn-outline-secondary" href="#">Ratirat</a>

	<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
	<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarCollapse">
	<ul class="navbar-nav me-auto mb-2 mb-md-0">
	<li class="nav-item">
	<a class="nav-link px-2  link-dark btn btn-outline-danger" aria-current="page" href="http://[::1]/CI/index.php/bootstrap/">หน้าแรก</a>

	</li>
	<li class="nav-item">
	<a href="http://[::1]/CI/index.php/about/" class="nav-link px-2  link-dark btn btn-outline-primary" >ประวัติส่วนตัว</a>

	</li>
	<li class="nav-item">
	<a  href="http://[::1]/CI/index.php/perfor/" class= "nav-link px-2   link-dark btn btn-outline-warning">ผลงานทางวิชาการ</a>

  </li>
	<li class="nav-item">
	<a href="http://[::1]/CI/index.php/activity/" class="nav-link px-2  link-dark btn btn-outline-success">กิจกรรม</a>

  </li>
	<li class="nav-item">
	<a href="http://[::1]/CI/index.php/cn/" class="nav-link px-2  link-dark btn btn-outline-danger">ติดต่อข้อมูล</a>
	</li>
	</ul>
	<form class="d-flex" role="search">
	<input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
	<button class="btn btn-outline-success" type="submit">Search</button>
	</form>
	</div>
	</div>
	</nav>
	</header>

  <header class="p-3 text-bg-dark">
    <div class="collapse bg-dark" id="navbarHeader">
         <div class="container">
            <div class="row">
              <div class="col-sm-8 col-md-7 py-4">
                 
        </div>
      </div>
    </div>
  </div>
  <div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container">
       
    </div>
  </div>
      
  </header>


</body>
</html>

      <main>
        <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body">
          <div class="col-md-5 p-lg-5 mx-auto my-5">
            <h1 class="display-1ุ5 fw-normal">Hello</h1>
            <p class="lead fw-normal">ยินดีต้อนรับเข้าสู่หน้าเพจของฉัน.</p>  
            <a href="https://youtu.be/_JrEuJhxOrQ" class="link-success">Blackbeans</a>
            <br><br><br>
            <img src="https://i.pinimg.com/originals/fb/99/58/fb9958cf8a1d82d741f49404c2284de9.jpg" alt="" width="400px">
      </main>
