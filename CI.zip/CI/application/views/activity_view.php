<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Activity</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Prompt&display=swap" rel="stylesheet">
</head>

<body>
<!--การสร้างเมนู-->
<style>
  div{
    background-color: #000000;
    background-image: url('https://www.bloggang.com/data/inkispy/picture/1257736167.jpg');
    background-position: center;
    text-shadow: 5px 5px 5px rgba(0, 0, 0, 0.8);
    font-family: 'Prompt', monospace;
      
  }
      
</style>
<header class="p-3 text-bg-dark">
    <div class="collapse bg-dark" id="navbarHeader">
         <div class="container">
            <div class="row">
              <div class="col-sm-8 col-md-7 py-4">
                 
        </div>
      </div>
    </div>
  </div>
  <div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container">
      <a href="#" class="navbar-brand d-flex align-items-center link-dark">
        <svg xmlns="http://www.w3.org/2000/svg " width="20" height="20" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" aria-hidden="true" class="me-2" viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
        <strong>Mint</strong>
       
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </div>
      </a>
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="http://[::1]/CI/index.php/bootstrap/" class="nav-link px-2  link-light btn btn-outline-danger "width="20" height="20">หน้าแรก</a></li>
          <li><a href="http://[::1]/CI/index.php/about/" class="nav-link px-2 link-light btn btn-outline-primary">ประวัติส่วนตัว</a></li>
          <li><a href="http://[::1]/CI/index.php/perfor/" class="nav-link px-2 link-light btn btn-outline-warning">ผลงานทางวิชาการ</a></li>
          <li><a href="http://[::1]/CI/index.php/activity/" class="nav-link px-2 link-light btn btn-outline-success">กิจกรรม</a></li>
          <li><a href="http://[::1]/CI/index.php/cn/" class="nav-link px-2 link-light btn btn-outline-danger">ติดต่อข้อมูล</a></li>
        </ul>
      
  </header>
</body>
</html>
<main>
      <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body">
        <div class="col-md-5 p-lg-5 mx-auto my-5">
          <h1 class="display-1.5 fw-normal link-dark">กิจกรรม</h1>
          <img src="http://[::1]/CI/img/m3.jpg" alt="" width="500px">
          <p class="lead fw-normal  link-dark">แข่งโดรน</p> 
          <br>
          <img src="http://[::1]/CI/img/m2.jpg" alt="" width="500px">
          <p class="lead fw-normal  link-dark">งานไหว้ครูคณะวิทยาศาสตร์</p>
          <br>
          <img src="http://[::1]/CI/img/m1.jpg" alt="" width="500px">
          <p class="lead fw-normal  link-dark">งานไหว้ศาลตากสิน</p>
          
    </main>
</body>
</html>
