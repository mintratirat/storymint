<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to HELLO WORLD</title>
</head>

<body>
<div id="container">
	<h1>HELLO WORLD</h1>


	<h1>HTML Helper</h1>
	aaaa<br>bbbb
	<br>
	cccc
	<?php echo br(5);?>
	dddd

	<p>Ratirat</p>
	<h1>H1</h1>
	<h2>H2</h2>
	<h6>H6</h6>

	<?php 
	echo heading("Ratirat",1);
	echo heading("Ratirat",2);
	echo heading("Ratirat",3);
	echo heading("Ratirat",4);
	echo heading("Ratirat",5);
	?>
	<hr>
	<p>OL</p>
	<?php
	     $list=array('a','b','c','d');
		 echo ol($list);
		 echo '<hr>';
		 echo ul($list);
	?>

	

</body>
</html>
